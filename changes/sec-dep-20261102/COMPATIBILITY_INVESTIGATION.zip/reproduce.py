"""Reproduce public-package diagnostics in a new, isolated Linux x64 directory."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

source=Path(__file__).resolve().parent
target=Path(sys.argv[1]).resolve();target.mkdir(parents=True,exist_ok=False)
scripts=['get_bun.py','fetch_public.py','build_fixtures.py','propose-interop.py','propose-vendor.py','bun-canary.py','consumer-probe.cjs','bounded-minimatch.cjs','bounded-glob.cjs','locked-subset.json']
for name in scripts:shutil.copyfile(source/name,target/name)
(target/'bun').mkdir();shutil.copyfile(source/'bun/provenance.json',target/'bun/provenance.json')
receipts=[]
steps=[['python','get_bun.py'],['python','fetch_public.py'],['python','build_fixtures.py'],['python','propose-interop.py'],['python','propose-vendor.py'],['python','bun-canary.py'],['node','consumer-probe.cjs'],['node','--max-old-space-size=128','bounded-minimatch.cjs'],['node','--max-old-space-size=128','bounded-glob.cjs']]
for index,command in enumerate(steps):
    result=subprocess.run(command,cwd=target,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=240)
    (target/f'step-{index}.log').write_text(result.stdout)
    receipts.append({'command':command,'exit':result.returncode});(target/'reproduction-exits.json').write_text(json.dumps(receipts,indent=2)+'\n')
    if result.returncode:raise RuntimeError(f'Failed {command}; inspect {target}/step-{index}.log')
    print(command,'controller exit',result.returncode,flush=True)
