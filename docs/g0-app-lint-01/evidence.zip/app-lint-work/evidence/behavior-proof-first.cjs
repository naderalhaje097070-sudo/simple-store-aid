const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const modules=process.env.APP_LINT_MODULES||'/workspace/scratch/ef360bbe5cf9/simple-store-aid/node_modules/';
const ts=require(modules+'typescript'),parser=require(modules+'@babel/parser');
const before=fs.readFileSync('app-lint-work/app.before.tsx','utf8');
const after=fs.readFileSync('app-lint-work/src/routes/_authenticated/app.tsx','utf8');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
function once(s,a,b){assert.equal(s.split(a).length,2);return s.replace(a,b)}
let expected=once(before,'      n.has(id) ? n.delete(id) : n.add(id);','      if (n.has(id)) n.delete(id);\n      else n.add(id);');
expected=once(expected,'                p.setOpenCustomerId(r.customer.id);','                if (r.customer === undefined) throw new TypeError("Debt customer is unavailable");\n                p.setOpenCustomerId(r.customer.id);');
expected=once(expected,'console.warn(err?.message);','console.warn(err === null || err === undefined ? undefined : Reflect.get(Object(err), "message", err));');
expected=once(expected,'} catch (e: any) {','} catch {');
const excluded=new Set(['start','end','loc','extra','comments','leadingComments','trailingComments','innerComments','tokens','errors']);
function clean(x){if(Array.isArray(x))return x.map(clean);if(!x||typeof x!=='object')return x;return Object.fromEntries(Object.entries(x).filter(([k])=>!excluded.has(k)).map(([k,v])=>[k,clean(v)]))}
const emit=s=>ts.transpileModule(s,{fileName:'app.tsx',compilerOptions:{target:ts.ScriptTarget.ESNext,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.React,removeComments:true}}).outputText;
const ast=s=>clean(parser.parse(emit(s),{sourceType:'module'}));
const expectedAST=ast(expected);assert.deepEqual(expectedAST,ast(after));
const controls=[];
for(const [name,a,b]of [
 ['financial total','const cashToday = collected - expenseTotal;','const cashToday = collected + expenseTotal;'],
 ['hook dependency','[p.invoices, p.products]','[p.invoices]'],
 ['RPC payload','paid: d.paid,','paid: 0,'],
 ['navigation','p.go("debt_customer");','p.go("home");'],
 ['message receiver','Reflect.get(Object(err), "message", err)','Reflect.get(Object(err), "message")'],
]){assert.notDeepEqual(expectedAST,ast(once(after,a,b)));controls.push(name)}
const result={beforeSha256:hash(before),afterSha256:hash(after),typescript:ts.version,babelParser:require(modules+'@babel/parser/package.json').version,approvedEmittedASTSha256:hash(JSON.stringify(expectedAST)),wholeEmittedASTMatchesExplicitApprovedChanges:true,negativeControlsRejected:controls,approvedRuntimeChanges:['discarded ternary to if/else; same condition and branch side effects','explicit undefined-customer TypeError before navigation; class/side effects preserved, error message clarified; underlying fault deferred','unknown thrown value message read preserves nullish and original receiver semantics','unused catch binding removed'],scope:'Static whole-file emission proof plus independent callback replay; does not certify live database or UI journeys'};
fs.writeFileSync('app-lint-work/evidence/behavior-proof.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
