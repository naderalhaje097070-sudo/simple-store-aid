import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root=Path(__file__).resolve().parent
directory=root/'fixtures/compatibility-proposal';directory.mkdir(parents=True,exist_ok=True)
package={'private':True,'name':'isolated-public-interop-proposal','dependencies':{'@eslint/config-array':'0.21.2','@eslint/eslintrc':'3.3.5','filelist':'1.0.6','glob':'11.1.0'},'overrides':{'glob':'14.0.2','minimatch':'11.0.1'},'resolutions':{'glob':'14.0.2','minimatch':'11.0.1'}}
(directory/'package.json').write_text(json.dumps(package,indent=2)+'\n')
(directory/'bunfig.toml').write_text('[install]\nminimumReleaseAge = 86400\n')
(directory/'.npmrc').write_text('registry=https://registry.npmjs.org\n')
commands=[]
def run(version,args,required=True,cache='proposal-cache'):
    cmd=[str(root/('bun/bun-'+version)),*args,'--ignore-scripts','--no-progress','--registry=https://registry.npmjs.org','--cache-dir='+str(root/cache),'--backend=copyfile']
    result=subprocess.run(cmd,cwd=directory,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60,env={**os.environ,'DO_NOT_TRACK':'1'})
    commands.append({'command':cmd,'exit':result.returncode,'output':result.stdout});(root/'proposal-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if required and result.returncode:raise RuntimeError(result.stdout)
    return result
lock=directory/'bun.lock'
if lock.exists():
    if not (directory/'initial-fresh-v2.bun.lock').exists():shutil.copyfile(lock,directory/'initial-fresh-v2.bun.lock')
    lock.unlink()
(directory/'package.json').write_text(json.dumps({k:v for k,v in package.items() if k not in ['overrides','resolutions']},indent=2)+'\n')
run('1.2.14',['install'])
shutil.copyfile(directory/'bun.lock',directory/'baseline-v1.bun.lock')
(directory/'package.json').write_text(json.dumps(package,indent=2)+'\n')
run('1.4.0',['install'])
run('1.4.0',['patch','minimatch@11.0.1'])
engine=directory/'node_modules/minimatch'
before={p.relative_to(engine).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in engine.rglob('*') if p.is_file()}
edits={'dist/commonjs/index.js':'\n// MONJEZ proposal: preserve legacy CommonJS callable/default interop.\nmodule.exports = Object.assign(exports.minimatch, exports);\n',
       'dist/esm/index.js':'\n// MONJEZ proposal: preserve legacy default import interop.\nexport default minimatch;\n',
       'dist/commonjs/index.d.ts':'\nexport default minimatch;\n',
       'dist/esm/index.d.ts':'\nexport default minimatch;\n'}
for name,addition in edits.items():
    p=engine/name;raw=p.read_text();assert 'export default minimatch;' not in raw and 'module.exports = Object.assign' not in raw
    p.write_text(raw+addition)
after={p.relative_to(engine).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in engine.rglob('*') if p.is_file()}
changed=[p for p in before if before[p]!=after[p]];assert set(changed)==set(edits)
run('1.4.0',['patch','--commit','minimatch@11.0.1'])
patches=list((directory/'patches').glob('*.patch'));assert len(patches)==1
rawlock=(directory/'bun.lock').read_bytes();lockhash=hashlib.sha256(rawlock).hexdigest()
shutil.rmtree(directory/'node_modules')
run('1.2.14',['install','--frozen-lockfile'],cache='proposal-consumer-cache')
assert hashlib.sha256((directory/'bun.lock').read_bytes()).hexdigest()==lockhash
normalizations=[]
for name,digest in after.items():
    actual=(engine/name).read_bytes()
    if hashlib.sha256(actual).hexdigest()==digest:continue
    # The Bun1.2 patch applier preserves the original no-final-LF state.
    # Accept exactly one final LF difference on the four intended additions.
    assert name in edits,name
    original=(root/'packages/inspect/minimatch'/name).read_bytes()
    assert actual==(original+edits[name].encode()).removesuffix(b'\n'),name
    normalizations.append(name)
(directory/'esm-entry.mjs').write_text('export {ConfigArray} from "@eslint/config-array";\n')
receipt={'prototype_only':True,'application_source':json.loads((root/'locked-subset.json').read_text())['source'],'application_package_changes':0,'generator':'1.4.0','fresh_frozen_consumer':'1.2.14','lock_header':rawlock.decode().splitlines()[:4],'lock_sha256':lockhash,'modified_engine_files':changed,'unchanged_engine_files':len(before)-len(changed),'patch_file':patches[0].name,'patch_sha256':hashlib.sha256(patches[0].read_bytes()).hexdigest(),'fresh_consumer_unchanged_files_exact_and_only_intended_interop_additions':True,'only_final_LF_normalized':normalizations,'commands':commands}
(root/'proposal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
