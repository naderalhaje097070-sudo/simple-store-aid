"""Bounded direct-CREATE source order analysis. Not a PostgreSQL catalog/runtime parser."""
import hashlib
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else __file__).resolve().parent
if len(sys.argv) > 1:
    ROOT = pathlib.Path(sys.argv[1]).resolve()


def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def direct_functions(path):
    text = path.read_text()
    # Relevant source uses direct CREATE at statement starts and simple argument lists.
    # This intentionally does not interpret grants, PL/pgSQL execution, RLS, dynamic SQL or DROP.
    start = re.compile(r"^CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+(?:public\.)?(\w+)\s*\((.*?)\)\s*", re.M | re.S | re.I)
    for match in start.finditer(text):
        dollar = re.search(r"\bAS\s+(\$[\w]*\$)", text[match.end():], re.I)
        if dollar is None:
            continue
        delimiter = dollar.group(1)
        body_start = match.end() + dollar.end()
        body_end = text.find(delimiter, body_start)
        if body_end < 0:
            raise ValueError(f"Unclosed function body in {path}")
        yield {"name": match.group(1).lower(), "arguments": re.sub(r"\s+", " ", match.group(2)).strip(), "path": path.relative_to(ROOT).as_posix(), "line": text[:match.start()].count("\n") + 1, "body": text[body_start:body_end], "statement": text[match.start():body_end+len(delimiter)]}


main = sorted((ROOT / "main/supabase/migrations").glob("*.sql"))
candidates = sorted((ROOT / "pr50/supabase/migrations").glob("20260815*.sql"))
assert len(main) == 50
assert len(candidates) == 2
sources = main + candidates
tracked = {"create_sale_with_items", "create_sale_with_items_v2", "_create_sale_with_items_core", "create_sale_with_items_idempotent", "update_courier_order_state", "update_courier_outcome_v2", "_assert_staff", "current_tenant_id"}


def trace(sequence):
    final = {}
    events = []
    for path in sequence:
        for item in direct_functions(path):
            if item["name"] in tracked:
                # Reject unexpected overloads instead of silently mixing signatures.
                arity = item["arguments"].count(",") + 1 if item["arguments"] else 0
                known = {"create_sale_with_items": 6, "create_sale_with_items_v2": 7, "_create_sale_with_items_core": 8, "create_sale_with_items_idempotent": 8, "update_courier_order_state": 3, "update_courier_outcome_v2": 4, "_assert_staff": 1, "current_tenant_id": 0}
                assert arity == known[item["name"]], (item["name"], item["arguments"])
                final[item["name"]] = item
                events.append({key: item[key] for key in ["name", "arguments", "path", "line"]})
    summary = {}
    for name, item in final.items():
        summary[name] = {"path": item["path"], "line": item["line"], "body_sha256": hashlib.sha256(item["body"].encode()).hexdigest(), "calls_active_actor_directly": "monjez_private.assert_active_actor()" in item["body"], "calls_assert_staff": "public._assert_staff(" in item["body"], "delegates_v2_transition": "public.update_courier_outcome_v2(" in item["body"], "delegates_core": "public._create_sale_with_items_core(" in item["body"]}
    return summary, events


baseline, base_events = trace(main)
fresh, fresh_events = trace(sorted(sources, key=lambda p: p.name))
upgrade, upgrade_events = trace(main + candidates)
legacy_names = ["create_sale_with_items", "update_courier_order_state"]
differences = [name for name in legacy_names if fresh[name]["body_sha256"] != upgrade[name]["body_sha256"]]
assert differences == legacy_names
assert not fresh["update_courier_order_state"]["delegates_v2_transition"]
assert upgrade["update_courier_order_state"]["delegates_v2_transition"]
assert not fresh["create_sale_with_items"]["delegates_core"]
assert upgrade["create_sale_with_items"]["delegates_core"]
assert fresh["_assert_staff"]["calls_active_actor_directly"]
assert upgrade["_assert_staff"]["calls_active_actor_directly"]
assert fresh["create_sale_with_items_idempotent"]["calls_assert_staff"]

schema = (ROOT / "main/supabase/migrations/20260626143241_8c05ee08-2167-458f-8092-777dcc86d8fe.sql").read_text()
assert re.search(r"stock\s+(?:integer|int)\b", schema, re.I)
assert re.search(r"qty\s+numeric", schema, re.I)
sale = (ROOT / "pr50/supabase/migrations/20260815170000_fin_courier_pr_a.sql").read_text()
assert "v_qty numeric(12,2)" in sale
assert "stock = stock - v_qty" in sale
idem = (ROOT / "pr50/supabase/migrations/20260815171000_fin_idem_sale_create.sql").read_text()
assert "REVOKE EXECUTE ON FUNCTION public.create_sale_with_items(" in idem
assert "REVOKE EXECUTE ON FUNCTION public.create_sale_with_items_v2(" in idem
assert "v_existing_request <> v_request" in idem
assert "ON CONFLICT (tenant_id, operation, idempotency_key) DO NOTHING" in idem

evidence = {"evidence_level": "direct source-order analysis only; no SQL execution/catalog/ACL proof", "main_migrations": len(main), "candidate_migrations": len(candidates), "inputs": [{"path": p.relative_to(ROOT).as_posix(), "git_blob": git_blob(p.read_bytes())} for p in sources], "baseline": baseline, "fresh_52_lexical_order": fresh, "hypothetical_upgrade_50_then_2": upgrade, "order_dependent_legacy_definitions": differences, "tracked_replacements": {"baseline": base_events, "fresh": fresh_events, "upgrade": upgrade_events}, "assertions": {"legacy_transition_differs_by_order": True, "legacy_sale_differs_by_order": True, "live_assert_staff_retained_in_both_source_orders": True, "idempotent_entry_calls_assert_staff": True, "integer_stock_numeric_item_quantity": True, "legacy_sale_revocation_present_in_candidate50": True, "exact_json_replay_comparison_present": True}, "composition_safe": False, "runtime_acceptance": False, "limitations": ["Hypothetical upgrade appends backdated August files after accepted50; this is not a Supabase upgrade execution", "Relevant direct CREATE statements are inspected; dynamic SQL, DROP/ALTER/ACL semantics and PLpgSQL execution are not interpreted", "No claim that CREATE OR REPLACE regrants revoked permissions", "Whole-unit vs fractional business policy remains unresolved", "Catalog/ACL/RLS and populated persisted financial behavior require later isolated native gates"]}
print(json.dumps(evidence, indent=2))
