import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

root=Path(__file__).resolve().parent
source=root/'packages/inspect/minimatch'
archive=root/'vendor/minimatch-11.0.1-monjez-interop.tgz';archive.parent.mkdir(exist_ok=True)
edits={'dist/commonjs/index.js':'\n// MONJEZ proposal: preserve legacy CommonJS callable/default interop.\nmodule.exports = Object.assign(exports.minimatch, exports);\n',
       'dist/esm/index.js':'\n// MONJEZ proposal: preserve legacy default import interop.\nexport default minimatch;\n',
       'dist/commonjs/index.d.ts':'\nexport default minimatch;\n',
       'dist/esm/index.d.ts':'\nexport default minimatch;\n'}
records=[]
with archive.open('wb') as handle,gzip.GzipFile(filename='',fileobj=handle,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
    for p in sorted(source.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(source).as_posix();before=p.read_bytes();after=before+edits.get(rel,'').encode()
        info=tarfile.TarInfo('package/'+rel);info.size=len(after);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
        tar.addfile(info,io.BytesIO(after));records.append({'path':rel,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'changed':before!=after})
assert {r['path'] for r in records if r['changed']}==set(edits)
directory=root/'fixtures/vendor-interop-proposal';directory.mkdir(parents=True,exist_ok=True)
package={'private':True,'name':'isolated-public-vendor-interop-proposal','dependencies':{'@eslint/config-array':'0.21.2','@eslint/eslintrc':'3.3.5','filelist':'1.0.6','glob':'11.1.0'},'overrides':{'glob':'14.0.2','minimatch':'file:../../vendor/minimatch-11.0.1-monjez-interop.tgz'},'resolutions':{'glob':'14.0.2','minimatch':'file:../../vendor/minimatch-11.0.1-monjez-interop.tgz'}}
(directory/'package.json').write_text(json.dumps(package,indent=2)+'\n')
(directory/'bunfig.toml').write_text('[install]\nminimumReleaseAge = 86400\n')
(directory/'.npmrc').write_text('registry=https://registry.npmjs.org\n')
commands=[]
def run(version,args,cache):
    cmd=[str(root/('bun/bun-'+version)),*args,'--ignore-scripts','--no-progress','--registry=https://registry.npmjs.org','--cache-dir='+str(root/cache),'--backend=copyfile']
    result=subprocess.run(cmd,cwd=directory,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60,env={**os.environ,'DO_NOT_TRACK':'1'})
    commands.append({'command':cmd,'exit':result.returncode,'output':result.stdout});(root/'vendor-proposal-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if result.returncode:raise RuntimeError(result.stdout)
lock=directory/'bun.lock'
if lock.exists():shutil.copyfile(lock,directory/'initial-fresh-v2.bun.lock');lock.unlink()
(directory/'package.json').write_text(json.dumps({k:v for k,v in package.items() if k not in ['overrides','resolutions']},indent=2)+'\n')
run('1.2.14',['install'],'vendor-proposal-baseline-cache')
shutil.copyfile(directory/'bun.lock',directory/'baseline-v1.bun.lock')
(directory/'package.json').write_text(json.dumps(package,indent=2)+'\n')
run('1.4.0',['install'],'vendor-proposal-cache')
rawlock=(directory/'bun.lock').read_bytes();lockhash=hashlib.sha256(rawlock).hexdigest()
shutil.rmtree(directory/'node_modules')
run('1.2.14',['install','--frozen-lockfile'],'vendor-proposal-consumer-cache')
assert hashlib.sha256((directory/'bun.lock').read_bytes()).hexdigest()==lockhash
engine=directory/'node_modules/minimatch'
for row in records:assert hashlib.sha256((engine/row['path']).read_bytes()).hexdigest()==row['after_sha256'],row['path']
(directory/'esm-entry.mjs').write_text('export {ConfigArray} from "@eslint/config-array";\n')
receipt={'prototype_only':True,'application_package_changes':0,'application_source':json.loads((root/'locked-subset.json').read_text())['source'],'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_path':str(archive.relative_to(root)),'archive_size':archive.stat().st_size,'archive_files':records,'generator':'1.4.0','fresh_frozen_consumer':'1.2.14','lock_header':rawlock.decode().splitlines()[:4],'lock_sha256':lockhash,'all_installed_engine_files_match':True,'commands':commands,'publisher_range_exception_not_adopted':True}
(root/'vendor-proposal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'files':len(records),'modified_files':sum(x['changed'] for x in records),'lock_header':receipt['lock_header'],'archive_sha256':receipt['archive_sha256'],'fresh_frozen_install':'pass','archive_size':receipt['archive_size']}))
