import json
import os
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parent
records=[]
for name,rule in [('nested',{'filelist':{'minimatch':'11.0.1'}}),('selector',{'minimatch@^5':'11.0.1'})]:
    directory=root/'bun-fixtures'/name;directory.mkdir(parents=True,exist_ok=True)
    package={'private':True,'name':'public-compatibility-canary','dependencies':{'filelist':'1.0.6'},'overrides':rule}
    (directory/'package.json').write_text(json.dumps(package,indent=2)+'\n')
    (directory/'bunfig.toml').write_text('[install]\nminimumReleaseAge = 86400\n')
    (directory/'.npmrc').write_text('registry=https://registry.npmjs.org\n')
    cmd=[str(root/'bun/bun-1.4.0'),'install','--lockfile-only','--ignore-scripts','--no-progress','--registry=https://registry.npmjs.org','--cache-dir='+str(root/'bun-cache')]
    result=subprocess.run(cmd,cwd=directory,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60,env={**os.environ,'DO_NOT_TRACK':'1'})
    (directory/'generator.log').write_text(result.stdout)
    row={'rule':name,'generator_command':cmd,'generator_exit':result.returncode,'generator_output':result.stdout,'requested_minimatch':'11.0.1','application_changes':0}
    lock=directory/'bun.lock'
    if lock.exists():
        text=lock.read_text();row['resolved_minimatch_lines']=[l for l in text.splitlines() if '["minimatch@' in l];row['lock_header']=text.splitlines()[:4]
        frozen=[str(root/'bun/bun-1.2.14'),'install','--frozen-lockfile','--ignore-scripts','--no-progress','--registry=https://registry.npmjs.org','--cache-dir='+str(root/'bun-cache')]
        old=subprocess.run(frozen,cwd=directory,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60,env={**os.environ,'DO_NOT_TRACK':'1'})
        row['consumer_command']=frozen;row['consumer_exit']=old.returncode;row['consumer_output']=old.stdout;(directory/'consumer.log').write_text(old.stdout)
    records.append(row)
(root/'bun-canary-results.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
