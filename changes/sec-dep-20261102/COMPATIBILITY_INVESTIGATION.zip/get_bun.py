import base64
import hashlib
import io
import json
from pathlib import Path
import tarfile
import urllib.request

root=Path(__file__).resolve().parent
for receipt in json.loads((root/'bun/provenance.json').read_text()):
    raw=urllib.request.urlopen(receipt['tarball'],timeout=45).read()
    assert 'sha512-'+base64.b64encode(hashlib.sha512(raw).digest()).decode()==receipt['integrity_verified']
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
        members=[m for m in tar.getmembers() if m.isfile() and m.name.endswith('/bin/bun')]
        assert len(members)==1
        binary=tar.extractfile(members[0]).read()
    assert hashlib.sha256(binary).hexdigest()==receipt['binary_sha256']
    p=root/'bun'/('bun-'+receipt['version']);p.write_bytes(binary);p.chmod(0o755)
    print('verified official Bun',receipt['version'])
