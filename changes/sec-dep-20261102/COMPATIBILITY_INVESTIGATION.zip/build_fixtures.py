import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parent
entries=json.loads((ROOT/'locked-subset.json').read_text())['entries']
def target(key):
    parents=[p for p in entries if key.startswith(p+'/')]
    if not parents:return Path(key)
    parent=max(parents,key=len)
    return target(parent)/'node_modules'/key[len(parent)+1:]
def copy(source,dest):
    if dest.exists():shutil.rmtree(dest)
    shutil.copytree(source,dest)

base=ROOT/'fixtures'/'baseline'/'node_modules'
for key in sorted(entries,key=len):copy(ROOT/'packages'/'locked'/key,base/target(key))
copy(ROOT/'packages'/'inspect'/'@eslint/eslintrc',base/'@eslint/eslintrc')
for variant in ['patched-engine','blind-global']:
    node=ROOT/'fixtures'/variant/'node_modules'
    copy(base,node)
    # These are isolated diagnostic fixtures, not changes to the application.
    copy(ROOT/'packages'/'inspect'/'minimatch',node/'minimatch')
    copy(ROOT/'packages'/'locked'/'glob/minimatch/brace-expansion',node/'minimatch/node_modules/brace-expansion')
    copy(ROOT/'packages'/'locked'/'glob/minimatch/brace-expansion/balanced-match',node/'minimatch/node_modules/brace-expansion/node_modules/balanced-match')
    copy(ROOT/'packages'/'inspect'/'@isaacs/nonrecursive-glob-match',node/'minimatch/node_modules/@isaacs/nonrecursive-glob-match')
    copy(ROOT/'packages'/'inspect'/'glob',node/'glob')
    copy(ROOT/'packages'/'inspect'/'path-scurry',node/'path-scurry')
    copy(ROOT/'packages'/'locked'/'path-scurry/lru-cache',node/'path-scurry/node_modules/lru-cache')
    if variant=='blind-global':
        copy(node/'minimatch',node/'filelist/node_modules/minimatch')
    else:
        # A manually materialized scoped graph, not a proposed/edited lockfile.
        copy(node/'minimatch',node/'glob/node_modules/minimatch')
        copy(ROOT/'packages'/'locked'/'minimatch',node/'minimatch')
    # Dynamic ESM resolution uses the actual config-array import entry.
    (node.parent/'esm-entry.mjs').write_text('export {ConfigArray} from "@eslint/config-array";\n')
(base.parent/'esm-entry.mjs').write_text('export {ConfigArray} from "@eslint/config-array";\n')
files=ROOT/'dummy-files';files.mkdir(exist_ok=True)
for name,body in [('a.js','alpha'),('b.css','beta'),('skip.js','skip'),('.hidden.js','hidden'),('sub/c.js','child')]:
    p=files/name;p.parent.mkdir(exist_ok=True);p.write_text(body)
print(json.dumps({'fixture_variants':3,'locked_package_paths':len(entries),'application_package_changes':0,'source_scripts_executed':0}))
