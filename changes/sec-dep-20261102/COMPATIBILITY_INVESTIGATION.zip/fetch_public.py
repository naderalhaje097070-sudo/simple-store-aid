import base64
import concurrent.futures
import hashlib
import io
import json
from pathlib import Path
import tarfile
import urllib.request

ROOT = Path(__file__).resolve().parent
snapshot = json.loads((ROOT / 'locked-subset.json').read_text())
def fetch(item):
    key, package, version, expected = item
    url = 'https://registry.npmjs.org/' + package.replace('/', '%2f') + '/' + version
    meta = json.load(urllib.request.urlopen(url, timeout=40))
    assert meta['name'] == package and meta['version'] == version
    raw = urllib.request.urlopen(meta['dist']['tarball'], timeout=40).read()
    assert len(raw) < 20_000_000
    integrity = 'sha512-' + base64.b64encode(hashlib.sha512(raw).digest()).decode()
    assert integrity == meta['dist']['integrity'], (package, version, 'official integrity')
    if expected: assert integrity == expected, (package, version, 'locked integrity')
    archive = ROOT / 'archives' / (key.replace('/', '__') + '.tgz')
    archive.parent.mkdir(exist_ok=True); archive.write_bytes(raw)
    target = ROOT / 'packages' / key
    target.mkdir(parents=True, exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as tar:
        members = tar.getmembers()
        assert sum(m.size for m in members) < 80_000_000
        for member in members:
            if not member.isfile(): continue
            parts = Path(member.name).parts
            expected_root = 'FileList-v1.0.6' if (package, version) == ('filelist', '1.0.6') else 'package'
            assert parts[0] == expected_root and '..' not in parts and not member.name.startswith('/'), (package, member.name)
            p = target.joinpath(*parts[1:]); p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(tar.extractfile(member).read())
    return {'key': key, 'name': package, 'version': version, 'metadata_url': url,
            'tarball_url': meta['dist']['tarball'], 'official_sha512': integrity,
            'locked_integrity_checked': bool(expected), 'tarball_sha256': hashlib.sha256(raw).hexdigest(),
            'dependencies': meta.get('dependencies', {}), 'engines': meta.get('engines'),
            'exports': meta.get('exports'), 'main': meta.get('main'), 'scripts_executed': 0}

items = []
for key, entry in snapshot['entries'].items():
    package, version = entry[0].rsplit('@', 1)
    items.append(('locked/' + key, package, version, entry[3]))
for name, version in [('eslint','9.39.4'),('@eslint/eslintrc','3.3.5'),
                      ('@typescript-eslint/typescript-estree','8.59.0'),('workbox-build','7.4.1'),
                      ('minimatch','11.0.1'),('glob','14.0.2'),('path-scurry','3.0.0'),
                      ('@isaacs/nonrecursive-glob-match','1.0.1')]:
    items.append(('inspect/' + name, name, version, None))
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    records = list(pool.map(fetch, items))
(ROOT/'public-provenance.json').write_text(json.dumps({'captured_utc':'2026-11-02','source':snapshot['source'], 'packages':records},indent=2)+'\n')
print(json.dumps({'verified_archives':len(records),'locked_archives':sum(r['locked_integrity_checked'] for r in records),'lifecycle_scripts':0,'extra_dependencies':{r['name']:r['dependencies'] for r in records if r['key'].startswith('inspect/')}}))
