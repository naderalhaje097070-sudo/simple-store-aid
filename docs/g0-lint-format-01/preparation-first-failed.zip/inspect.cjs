const fs = require("node:fs");
const crypto = require("node:crypto");
const assert = require("node:assert/strict");
const cp = require("node:child_process");
const { ESLint } = require("eslint");
const prettier = require("prettier");
const ts = require("typescript");
const parser = require("@babel/parser");
const out = "/tmp/g0-lint-format";
const write = (p, d) => fs.writeFileSync(out + "/" + p, typeof d === "string" ? d : JSON.stringify(d, null, 2) + "\n");
const hash = (s) => crypto.createHash("sha256").update(s).digest("hex");
const norm = (v) => {
  if (Array.isArray(v)) return v.map(norm);
  if (!v || typeof v !== "object") return v;
  return Object.fromEntries(Object.entries(v).filter(([k]) => !["start","end","loc","extra","comments","leadingComments","innerComments","trailingComments","tokens","errors"].includes(k)).map(([k, v]) => [k, norm(v)]));
};
const semantic = (source) => {
  const r = ts.transpileModule(source, {
    fileName: "app.tsx",
    compilerOptions: { target: ts.ScriptTarget.ESNext, module: ts.ModuleKind.ESNext, jsx: ts.JsxEmit.React, removeComments: true },
    reportDiagnostics: true,
  });
  assert.equal(r.diagnostics.filter(d => d.category === ts.DiagnosticCategory.Error).length, 0);
  return norm(parser.parse(r.outputText, { sourceType: "module" }));
};
const comments = source => parser.parse(source, { sourceType:"module", plugins:["typescript","jsx"] }).comments.map(c=>({type:c.type,value:c.value}));
const diagnostics = rs => rs.flatMap(r => r.messages.filter(m=>m.ruleId!=="prettier/prettier").map(m => ({
  path:r.filePath.replace(process.cwd()+"/",""),ruleId:m.ruleId,severity:m.severity,message:m.message,nodeType:m.nodeType??null,messageId:m.messageId??null
}))).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
const summarize = rs => {
  const rules={},files=[];
  let errors=0,warnings=0;
  for(const r of rs){
    let format=0;
    for(const m of r.messages){rules[m.ruleId??"<null>"]=(rules[m.ruleId??"<null>"]??0)+1;if(m.ruleId==="prettier/prettier")format++;if(m.severity===2)errors++;else if(m.severity===1)warnings++;}
    if(r.messages.length)files.push({path:r.filePath.replace(process.cwd()+"/",""),format,errors:r.errorCount,warnings:r.warningCount});
  }
  return {errors,warnings,rules,files:files.sort((a,b)=>b.format-a.format)};
};
(async()=>{
const eslint = new ESLint();
const before = await eslint.lintFiles(["."]);
write("lint-before.json",before);
write("lint-before.exit",before.some(r=>r.errorCount)? "1\n":"0\n");
const summaryBefore=summarize(before);
write("summary-before.json",summaryBefore);
const generated=new Set([
"src/integrations/lovable/index.ts",
"src/integrations/supabase/auth-attacher.ts","src/integrations/supabase/auth-middleware.ts","src/integrations/supabase/client.server.ts","src/integrations/supabase/client.ts",
"src/routes/[.]mcp/list-tools.ts","src/routes/[.]mcp/invoke-tool/$tool.ts",
"src/routes/[.]well-known/oauth-protected-resource.ts","src/routes/mcp.ts"
]);
const candidates=summaryBefore.files.filter(f=>f.path.startsWith("src/")&&!generated.has(f.path)&&!/(?:auto[- ]?generated|do not edit|@generated)/i.test(fs.readFileSync(f.path,"utf8").slice(0,1600)));
write("handwritten-ranking.json",candidates);
const target=candidates[0].path;
assert.equal(target,"src/routes/_authenticated/app.tsx","Unexpected largest handwritten file: stop and review");
const original=fs.readFileSync(target,"utf8");
assert.equal(cp.execFileSync("git",["hash-object",target],{encoding:"utf8"}).trim(),"054c9640c5f7785e7fbac491108286d42e1c1c61");
const config=await prettier.resolveConfig(target);
write("formatter.json",{version:prettier.version,eslint:require("eslint/package.json").version,typescript:ts.version,babelParser:require("@babel/parser/package.json").version,config});
const formatted=await prettier.format(original,{...config,filepath:target});
assert.notEqual(original,formatted);
assert.equal(await prettier.check(formatted,{...config,filepath:target}),true);
assert.equal(await prettier.format(formatted,{...config,filepath:target}),formatted);
const a=semantic(original),b=semantic(formatted);
assert.deepEqual(a,b,"Emitted JS AST including runtime JSX child strings changed");
assert.deepEqual(comments(original),comments(formatted),"Comments changed");
write("ast-before.json",a);write("ast-after.json",b);
write("comments.json",comments(original));
fs.writeFileSync(target,formatted);
write("app.before.tsx",original);write("app.after.tsx",formatted);
const after=await eslint.lintFiles(["."]);
write("lint-after.json",after);
write("lint-after.exit",after.some(r=>r.errorCount)?"1\n":"0\n");
write("summary-after.json",summarize(after));
assert.deepEqual(diagnostics(before),diagnostics(after),"Nonformat diagnostics changed");
const old=before.find(r=>r.filePath.endsWith("/"+target));
const current=after.find(r=>r.filePath.endsWith("/"+target));
assert.equal(current.messages.filter(m=>m.ruleId==="prettier/prettier").length,0);
for(const r of before.filter(r=>r!==old))assert.deepEqual(r,after.find(a=>a.filePath===r.filePath),"Another file's diagnostics changed");
cp.execFileSync("git",["diff","--check"],{stdio:"inherit"});
assert.deepEqual(cp.execFileSync("git",["diff","--name-only"],{encoding:"utf8"}).trim().split("\n"),[target]);
const hashes={};
for(const p of ["package.json","bun.lock","bunfig.toml","eslint.config.js",".prettierrc",".prettierignore"])hashes[p]=cp.execFileSync("git",["hash-object",p],{encoding:"utf8"}).trim();
const result={target,before:summaryBefore,after:summarize(after),targetBefore:{errors:old.errorCount,warnings:old.warningCount,format:old.messages.filter(m=>m.ruleId==="prettier/prettier").length},targetAfter:{errors:current.errorCount,warnings:current.warningCount,format:0},originalSha256:hash(original),formattedSha256:hash(formatted),formattedBlob:cp.execFileSync("git",["hash-object",target],{encoding:"utf8"}).trim(),emittedASTSha256:hash(JSON.stringify(a)),sameEmittedAST:true,sameComments:true,nonformatDiagnosticsEqual:true,otherDiagnosticsByteEqual:true,protectedBlobs:hashes};
write("result.json",result);
write("app.diff",cp.execFileSync("git",["diff","--",target],{encoding:"utf8",maxBuffer:10e6}));
console.log(JSON.stringify({target,targetBefore:result.targetBefore,targetAfter:result.targetAfter,beforeErrors:summaryBefore.errors,afterErrors:result.after.errors,ast:result.emittedASTSha256}));
})().catch(e=>{console.error(e);process.exitCode=1;});

