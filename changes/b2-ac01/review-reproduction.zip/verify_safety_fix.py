"""Read-only B2 reviewer controls. No HTTP, SQL, or real credentials."""
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import tempfile
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'source'
identity = json.loads((HERE / 'candidate-7a4fb-preservation.json').read_text())
checks = []

def check(name, value):
    checks.append({'name':name, 'passed':bool(value)})
    if not value:
        raise AssertionError(name)

for relative, expected in identity['expected_local_blobs'].items():
    raw = (SOURCE / relative).read_bytes()
    actual = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    check('exact_source_blob:' + relative, actual == expected)

spec = importlib.util.spec_from_file_location('review_scanner_evidence', SOURCE / 'tests/account-lifecycle/scanner_evidence.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
marker = '.'.join(('eyJ' + 'A' * 12, 'B' * 12, 'C' * 12))

with tempfile.TemporaryDirectory(prefix='ac01-review-') as tmp:
    root = Path(tmp)
    out, quarantine = root / 'upload', root / 'quarantine'
    (out / 'nested').mkdir(parents=True)
    (out / 'nested' / 'bad.json').write_text(marker)
    (out / 'clean.json').write_text('{}')
    try:
        helper.verify_publication(out, quarantine)
    except helper.PublicationBlocked as error:
        check('credential_guard_raises_static_failure', str(error) == 'AC01_EVIDENCE_QUARANTINED')
    else:
        check('credential_guard_raises_static_failure', False)
    receipt = json.loads((out / 'publication-blocked.json').read_text())
    check('entire_batch_removed_from_sink', [p.name for p in out.iterdir()] == ['publication-blocked.json'])
    check('quarantine_contains_clean_and_bad_files', (quarantine / 'clean.json').is_file() and (quarantine / 'nested/bad.json').read_text() == marker)
    check('receipt_contains_no_marker', marker not in json.dumps(receipt))
    check('receipt_has_both_fingerprints', len(receipt['files']) == 2 and all('sha256' in x for x in receipt['files']))
    check('quarantine_directory_private', stat.S_IMODE(quarantine.stat().st_mode) == 0o700)

with tempfile.TemporaryDirectory(prefix='ac01-review-') as tmp:
    root = Path(tmp)
    out = root / 'upload'; out.mkdir()
    known = 'synthetic-' + 'password-' + 'canary-42'
    (out / 'bad.json').write_text(known)
    try:
        helper.verify_publication(out, root / 'quarantine', [known])
    except helper.PublicationBlocked:
        check('known_non_jwt_secret_is_quarantined', not (out / 'bad.json').exists() and known not in (out / 'publication-blocked.json').read_text())
    else:
        check('known_non_jwt_secret_is_quarantined', False)

with tempfile.TemporaryDirectory(prefix='ac01-review-') as tmp:
    root = Path(tmp)
    out = root / 'upload'; out.mkdir()
    (root / 'outside.json').write_text(marker)
    (out / 'link.json').symlink_to(root / 'outside.json')
    try:
        helper.verify_publication(out, root / 'quarantine')
    except helper.PublicationBlocked:
        receipt = json.loads((out / 'publication-blocked.json').read_text())
        check('symlink_is_quarantined_without_reading_target', receipt['files'][0]['reason'] == 'non-regular evidence' and 'sha256' not in receipt['files'][0] and not (out / 'link.json').exists())
    else:
        check('symlink_is_quarantined_without_reading_target', False)

with tempfile.TemporaryDirectory(prefix='ac01-review-') as tmp:
    root = Path(tmp)
    out = root / 'upload'; out.mkdir()
    (out / 'unreadable.json').write_text('{}')
    with patch.object(Path, 'read_bytes', side_effect=OSError('review injected I/O failure')):
        try:
            helper.verify_publication(out, root / 'quarantine')
        except OSError:
            check('read_failure_does_not_return_publication_permission', True)
        else:
            check('read_failure_does_not_return_publication_permission', False)

with tempfile.TemporaryDirectory(prefix='ac01-review-') as tmp:
    root = Path(tmp)
    out = root / 'upload'; out.mkdir()
    (out / 'bad.json').write_text(marker)
    quarantine = root / 'quarantine'; quarantine.mkdir()
    try:
        helper.verify_publication(out, quarantine)
    except ValueError:
        check('existing_quarantine_does_not_return_permission', True)
    else:
        check('existing_quarantine_does_not_return_permission', False)

with tempfile.TemporaryDirectory(prefix='ac01-review-') as tmp:
    root = Path(tmp)
    out = root / 'upload'; out.mkdir()
    raw = '{"passed":true}'
    (out / 'clean.json').write_text(raw)
    result = helper.verify_publication(out, root / 'quarantine')
    check('clean_positive_is_publishable_and_unchanged', result == {'publication_allowed':True, 'files':1} and (out / 'clean.json').read_text() == raw)

workflow = (SOURCE / '.github/workflows/b2-scanner-auth.yml').read_text()
cleanup = workflow[workflow.index('      - name: Cleanup and safe final receipts'):]
check('upload_uses_successful_publication_output', "if: always() && steps.publication.outputs.safe == 'true'" in cleanup)
check('publication_step_has_id_and_fail_fast_shell', 'id: publication' in cleanup and 'set -euo pipefail' in cleanup)
check('safe_output_occurs_after_guard_and_cleanup_assertion', cleanup.index('verify_publication(out,') < cleanup.index('assert before>0') < cleanup.index("echo 'safe=true' >> \"$GITHUB_OUTPUT\""))
check('only_one_safe_output_writer', workflow.count("echo 'safe=true'") == 1)
check('actual_secrets_loaded_before_guard_and_deletion', cleanup.index("for filename in ['status.json','private-state.json']") < cleanup.index('verify_publication(out,') < cleanup.index('finally:') < cleanup.index("subprocess.run(['sudo','rm'"))
result = {'source':identity['reviewed_source'], 'review_kind':'offline source and synthetic negative controls',
          'source_match':True,'checks':checks,'passed':len(checks),'failed':0,
          'upstream_unit_suite':{'command':'PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests/account-lifecycle -p test_scanner_auth_probe.py -v','tests':5,'failures':0,'exit':0},
          'db_or_http_actions':False,'real_credentials_used':False,'workflow_or_upload_executed':False,
          'limits':'I/O/quarantine failure is fail-closed through the independently inspected workflow output gate; the helper alone can leave an unsafe sink on exception. Evidence filenames in this workflow are fixed by reviewed source.'}
(HERE / 'credential-upload-after-7a4fb.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':result['source'],'passed':result['passed'],'failed':0,'unit_tests':5,'db_or_http_actions':False}))
