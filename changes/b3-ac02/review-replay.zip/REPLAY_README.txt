B3 optional offline raw-evidence replay

replay_evidence.py reads JSON, ZIP archives and their saved extracted members only.
It makes no HTTP, SQL, subprocess, Supabase, Auth or provider call and writes no
source/evidence file. It does not import or execute repository/application code.
This archive is manual evidence, not a CI input.

Example with original review layout:
python replay_evidence.py --records /path/to/b3/review --evidence /path/to/b3/evidence/final-native

Example with the published repository packet:
python replay_evidence.py --records /path/to/repo/changes/b3-ac02 --evidence /path/to/repo/changes/b3-ac02/evidence/final-native

The companion script rechecks core source attribution, original ZIP digests/member
identity, all reported native checks, effective column rights, inactive-account
INSERT/settings controls, upgrade catalogs, cleanup, advisor warnings and the open
audit barrier. The full original 207-comparison record remains in
final-native-verification.json (published as review-final-native-verification.json).
This compact companion does not recreate every one of those 207 comparisons and
is not a second live database test. The pure local oracle cases/mutations were
executed separately and are recorded in oracle-review-8f266.json.

The packaging step syntax-checked this recipe; it did not execute the recipe or
rerun native/unit suites. The review's actual source/oracle and raw-evidence replay
commands/results are disclosed in FINAL_ENTITLEMENT_REVIEW.md.
