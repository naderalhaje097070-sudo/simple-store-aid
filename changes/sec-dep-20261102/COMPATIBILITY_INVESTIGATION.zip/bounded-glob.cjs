const fs=require('node:fs'),path=require('node:path');
const rows=[];
const tree=path.join(__dirname,'abort-tree');
function seed(dir,depth){fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'dummy.js'),'dummy');if(depth)for(let i=0;i<2;i++)seed(path.join(dir,'child'+i),depth-1);}
seed(tree,3);
(async()=>{
for(const variant of ['baseline','patched-engine']){
 const {glob}=require(path.join(__dirname,'fixtures',variant,'node_modules/glob'));
 const ac=new AbortController();let calls=0,pending=0,atReject=0,atAbort=0,error;
 const instrumented={...fs,readdir(...args){
  calls++;pending++;const callback=args.pop();
  fs.readdir(...args,(...reply)=>{pending--;if(calls===1){atAbort=calls;ac.abort(new Error('bounded fixture abort'));}callback(...reply);});
 }};
 try{await glob('**/*.js',{cwd:tree,fs:instrumented,signal:ac.signal});}
 catch(e){error=e.message;atReject=calls;}
 // A bounded observation window in a fifteen-file/fifteen-directory dummy tree.
 await new Promise(resolve=>setTimeout(resolve,100));
 rows.push({variant,rejected_with:error,readdir_at_abort:atAbort,readdir_at_rejection:atReject,readdir_final:calls,readdir_after_abort:calls-atAbort,readdir_after_rejection:calls-atReject,pending_at_end:pending,observation_ms:100,tree_files:15,tree_directories:15});
}
fs.writeFileSync(path.join(__dirname,'bounded-glob-results.json'),JSON.stringify({runtime:process.version,production_calls:0,observations:rows},null,2)+'\n');console.log(JSON.stringify(rows));
})().catch(e=>{console.error(e);process.exitCode=1;});
