const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {createRequire}=require('node:module');
const root='/workspace/simple-store-aid',work='/workspace/.format03';
const project=createRequire(root+'/package.json');
const parser=project('@babel/parser'),ts=project('typescript'),prettier=project('prettier');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const excluded=new Set(['start','end','loc','extra','leadingComments','trailingComments','innerComments','comments','tokens','errors']);
const clean=x=>Array.isArray(x)?x.map(clean):x&&typeof x==='object'?Object.fromEntries(Object.entries(x).filter(([k])=>!excluded.has(k)).map(([k,v])=>[k,clean(v)])):x;
const parse=s=>parser.parse(s,{sourceType:'module',plugins:['typescript','jsx']});
function emit(s){const r=ts.transpileModule(s,{fileName:'probe.tsx',compilerOptions:{target:ts.ScriptTarget.ESNext,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.React,removeComments:true},reportDiagnostics:true});assert.equal(r.diagnostics.filter(d=>d.category===ts.DiagnosticCategory.Error).length,0);return r.outputText;}
function cook(raw){const expr=clean(parse(emit('const x=<x>'+raw+'</x>;'))).program.body[0].declarations[0].init;const args=expr.arguments.slice(2);assert(args.every(x=>x.type==='StringLiteral'));return args.map(x=>x.value).join('');}
function sourceCanonical(x){
 if(Array.isArray(x))return x.map(sourceCanonical);
 if(!x||typeof x!=='object')return x;
 const y=Object.fromEntries(Object.entries(x).map(([k,v])=>[k,sourceCanonical(v)]));
 if(y.type==='JSXElement'||y.type==='JSXFragment'){
  const host=y.type==='JSXElement'&&y.openingElement.name.type==='JSXIdentifier'&&/^[a-z]/.test(y.openingElement.name.name);
  const children=[];
  for(const c of y.children){
   const value=c.type==='JSXText'?cook(c.value):c.type==='JSXExpressionContainer'&&c.expression.type==='StringLiteral'?c.expression.value:null;
   if(value===null)children.push(c);
   else if(value!==''){
    if(host&&children.length&&children.at(-1).type==='StringLiteral')children.at(-1).value+=value;
    else children.push({type:'StringLiteral',value});
   }
  }
  y.children=children;
 }
 return y;
}
function runtimeCanonical(x){
 if(Array.isArray(x))return x.map(runtimeCanonical);
 if(!x||typeof x!=='object')return x;
 const y=Object.fromEntries(Object.entries(x).map(([k,v])=>[k,runtimeCanonical(v)]));
 if(y.type==='CallExpression'&&y.callee.type==='MemberExpression'&&y.callee.object.name==='React'&&y.callee.property.name==='createElement'&&y.arguments[0].type==='StringLiteral'){
  const args=y.arguments.slice(0,2);
  for(const c of y.arguments.slice(2)){
   if(c.type==='StringLiteral'&&args.length>2&&args.at(-1).type==='StringLiteral')args.at(-1).value+=c.value;
   else args.push(c);
  }
  y.arguments=args;
 }
 return y;
}
const sourceAST=s=>sourceCanonical(clean(parse(s)));
const runtimeAST=s=>runtimeCanonical(clean(parse(emit(s))));
const comments=s=>parse(s).comments.map(c=>({type:c.type,value:c.value}));
(async()=>{
 const receipt={versions:{prettier:prettier.version,typescript:ts.version,babelParser:project('@babel/parser/package.json').version,eslint:project('eslint/package.json').version},method:'TypeScript-cooked JSX text; contiguous text coalescing on intrinsic host elements only; custom component/fragment segmentation preserved',negativeControls:[],files:[],excluded:[]};
 assert.equal(prettier.version,'3.8.3');
 for(const [name,a,b] of [
  ['type','type A=string;','type A=number;'],
  ['meaningful host whitespace','const a=<span>a b</span>;','const a=<span>ab</span>;'],
  ['custom child segmentation','const a=<Custom>ab</Custom>;','const a=<Custom>a{"b"}</Custom>;'],
  ['callback','const a=()=>fetch("/a");','const a=()=>fetch("/b");'],
  ['hook dependencies','useEffect(()=>run(),[a]);','useEffect(()=>run(),[b]);']
 ]){assert.notDeepEqual(sourceAST(a),sourceAST(b));receipt.negativeControls.push(name);}
 const files=fs.readFileSync(work+'/files.txt','utf8').trim().split('\n');
 const pending=[];
 for(const file of files){
  const before=fs.readFileSync(work+'/before/'+file,'utf8');
  const current=fs.readFileSync(root+'/'+file,'utf8');
  assert(!/(?:auto[- ]?generated|do not edit|@generated)/i.test(before.slice(0,1600)),'Generated file must be excluded');
  const config=await prettier.resolveConfig(root+'/'+file);
  const after=await prettier.format(before,{...config,filepath:root+'/'+file});
  try{
   assert(current===before||current===after,'Only captured base or already-proven exact output may be written');
   assert.notEqual(before,after);
   assert.equal(await prettier.check(after,{...config,filepath:root+'/'+file}),true);
   assert.equal(await prettier.format(after,{...config,filepath:root+'/'+file}),after);
   const sourceA=sourceAST(before),sourceB=sourceAST(after);
   assert.deepEqual(sourceA,sourceB,'Source/type/meaningful JSX AST differs');
   const runtimeA=runtimeAST(before),runtimeB=runtimeAST(after);
   assert.deepEqual(runtimeA,runtimeB,'Runtime AST/JSX text differs');
   assert.deepEqual(comments(before),comments(after),'Comment contents/order differs');
   const out=work+'/after/'+file;fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,after);
   receipt.files.push({file,beforeSha256:hash(before),afterSha256:hash(after),sourceASTSha256:hash(JSON.stringify(sourceA)),runtimeASTSha256:hash(JSON.stringify(runtimeA)),sameSourceTypesAST:true,sameRuntimeAST:true,sameComments:true,prettierExactOutput:true,idempotent:true,config});
   pending.push([file,after]);
  }catch(error){receipt.excluded.push({file,reason:error.message.slice(0,1000)});}
 }
 fs.writeFileSync(work+'/evidence/proof.json',JSON.stringify(receipt,null,2)+'\n');
 for(const [file,after] of pending)fs.writeFileSync(root+'/'+file,after);
 console.log(JSON.stringify(receipt,null,2));
 assert(receipt.files.length>0,'No proven file eligible for publication');
})().catch(error=>{console.error(error);process.exitCode=1;});
