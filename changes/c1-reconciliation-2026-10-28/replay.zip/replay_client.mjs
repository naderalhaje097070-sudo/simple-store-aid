import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { stripTypeScriptTypes } from 'node:module';
import { createHash } from 'node:crypto';

const root = process.argv[2] ?? new URL('.', import.meta.url).pathname;
const candidatePath = `${root}/pr50/src/lib/db.ts`;
const mainPath = `${root}/main/src/lib/db.ts`;
const candidate = fs.readFileSync(candidatePath, 'utf8');
const main = fs.readFileSync(mainPath, 'utf8');
const blob = source => createHash('sha1').update(`blob ${Buffer.byteLength(source)}\0`).update(source).digest('hex');

function section(source, first, last) {
  const a = source.indexOf(first), b = source.indexOf(last, a);
  assert(a >= 0 && b > a, `Missing exact source anchors: ${first}`);
  return source.slice(a, b);
}

const selected = section(candidate, 'export type CourierCreateState', 'export function useDeleteInvoice');
const errorFormatter = section(candidate, 'function rpcMessage(', '/* ---------- products');
const compiled = stripTypeScriptTypes(errorFormatter + selected, { mode: 'strip' }).replace(/^export /gm, '');
const mainSelected = section(main, 'export type CreateSaleInput', 'export function useDeleteInvoice');
const mainCompiled = stripTypeScriptTypes(errorFormatter + mainSelected, { mode: 'strip' }).replace(/^export /gm, '');
const dummyInput = Object.freeze({ items: [{ productId: 'aaaaaaaa-0000-0000-0000-000000000001', name: 'Dummy', qty: 1, price: 100, cost: 60 }], total: 100, paid: 100, delivery: 'direct', method: 'cash' });
const cases = [];

function environment({ storage = new Map(), clock = { now: 1_000_000 }, transport, storageFault = false, code = compiled, prefix = 'candidate' } = {}) {
  let serial = 0;
  const namespace = createHash('sha256').update(prefix).digest('hex').slice(0, 8);
  const calls = [];
  const storageApi = {
    getItem: key => { if (storageFault) throw new Error('dummy storage unavailable'); return storage.get(key) ?? null; },
    setItem: (key, value) => { if (storageFault) throw new Error('dummy storage unavailable'); storage.set(key, value); },
    removeItem: key => { if (storageFault) throw new Error('dummy storage unavailable'); storage.delete(key); },
  };
  const rpc = async (name, payload) => { const record = { name, payload }; calls.push(record); return transport(record, calls.length); };
  const context = vm.createContext({
    window: { sessionStorage: storageApi },
    Date: class extends Date { static now() { return clock.now; } },
    crypto: { randomUUID: () => `${namespace}-0000-4000-8000-${(++serial).toString(16).padStart(12, '0')}` },
    supabase: { rpc }, rpcClient: { rpc },
    useQueryClient: () => ({ invalidateQueries() {} }),
    useMutation: options => options,
  });
  vm.runInContext(code + '\nthis.capture = { useCreateSale };', context, { timeout: 1000 });
  return { calls, storage, clock, mutate: input => context.capture.useCreateSale('dummy-tenant').mutationFn(input) };
}

async function lostResponse(label, elapsed, reload = false) {
  const storage = new Map(), clock = { now: 1_000_000 }, committed = new Map(), keys = [];
  let count = 0;
  const transport = ({ payload }) => {
    const key = payload.p_idempotency_key;
    keys.push(key);
    if (!committed.has(key)) committed.set(key, { success: true, order_id: `dummy-order-${committed.size + 1}`, number: committed.size + 1 });
    return ++count === 1 ? { data: null, error: { message: 'dummy lost response after modeled commit' } } : { data: committed.get(key), error: null };
  };
  let env = environment({ storage, clock, transport, prefix: 'first-context' });
  await assert.rejects(env.mutate(dummyInput), /تعذّر إتمام العملية/);
  clock.now += elapsed;
  if (reload) env = environment({ storage, clock, transport, prefix: 'reloaded-context' });
  await env.mutate(dummyInput);
  const changesKey = elapsed > 30 * 60 * 1000;
  assert.equal(keys[0] === keys[1], !changesKey);
  assert.equal(committed.size, changesKey ? 2 : 1);
  cases.push({ label, observation: changesKey ? 'DEFECT_REPRODUCED' : 'CONTROL_PASS', same_key: keys[0] === keys[1], modeled_effects: committed.size, elapsed_ms: elapsed, reload });
}

await lostResponse('short retry retains unresolved identity', 1000);
await lostResponse('retry after 30-minute window changes unresolved identity', 1_800_001);
await lostResponse('reload inside window retains unresolved identity', 1000, true);
await lostResponse('reload after window changes unresolved identity', 1_800_001, true);

{
  const committed = new Map(), keys = [];
  const env = environment({ transport: ({ payload }, n) => {
    keys.push(payload.p_idempotency_key);
    if (!committed.has(payload.p_idempotency_key)) committed.set(payload.p_idempotency_key, { success: true, order_id: `dummy-order-${committed.size + 1}`, number: committed.size + 1 });
    return n <= 2 ? { data: null, error: { message: 'dummy lost response' } } : { data: committed.get(payload.p_idempotency_key), error: null };
  } });
  await assert.rejects(env.mutate(dummyInput));
  await assert.rejects(env.mutate({ ...dummyInput, paid: 200, total: 200, items: [{ ...dummyInput.items[0], qty: 2 }] }));
  await env.mutate(dummyInput);
  assert.notEqual(keys[0], keys[2]);
  assert.equal(committed.size, 3);
  cases.push({ label: 'second unresolved submission replaces single pending slot', observation: 'DEFECT_REPRODUCED', first_retry_same_key: false, modeled_effects: committed.size });
}

{
  const env = environment({ transport: (_record, n) => n === 1 ? { data: null, error: null } : { data: { success: true, order_id: 'dummy-order', number: 1 }, error: null } });
  await assert.rejects(env.mutate(dummyInput), /order_id/);
  assert.equal(env.storage.size, 0);
  await env.mutate(dummyInput);
  assert.notEqual(env.calls[0].payload.p_idempotency_key, env.calls[1].payload.p_idempotency_key);
  cases.push({ label: 'null success result clears unresolved key before validating result', observation: 'DEFECT_REPRODUCED', next_call_same_key: false, no_database_effect_claimed: true });
}

{
  const env = environment({ transport: () => ({ data: { success: true, order_id: 'dummy-order', number: 1 }, error: null }) });
  await env.mutate(dummyInput);
  await env.mutate(dummyInput);
  assert.notEqual(env.calls[0].payload.p_idempotency_key, env.calls[1].payload.p_idempotency_key);
  cases.push({ label: 'new identical sale after definitive success receives new identity', observation: 'CONTROL_PASS', distinct_keys: true });
}

{
  const env = environment({ storageFault: true, transport: () => { throw new Error('must not reach transport'); } });
  await assert.rejects(env.mutate(dummyInput), /storage unavailable/);
  assert.equal(env.calls.length, 0);
  cases.push({ label: 'unavailable storage refuses before outbound write', observation: 'CONTROL_PASS', outbound_calls: 0 });
}

{
  const env = environment({ code: mainCompiled, transport: () => ({ data: { success: true, order_id: 'dummy-order', number: 1 }, error: null }) });
  await env.mutate(dummyInput);
  assert.equal(env.calls[0].name, 'create_sale_with_items');
  assert.equal(Object.hasOwn(env.calls[0].payload, 'p_courier_state'), false);
  assert.equal(Object.hasOwn(env.calls[0].payload, 'p_idempotency_key'), false);
  cases.push({ label: 'accepted main caller still uses legacy sale RPC', observation: 'CONTROL_PASS', rpc: env.calls[0].name, passes_outcome: false, passes_idempotency_key: false });
}

console.log(JSON.stringify({ evidence: 'Actual selected TypeScript callbacks and candidate rpcMessage compiled by Node built-in stripTypeScriptTypes and executed in isolated VM', candidate_blob: blob(candidate), main_blob: blob(main), actual_transport_or_database_calls: 0, transport: 'synthetic recording contract and valid-shape dummy UUIDs; modeled effects are NOT stored SQL evidence', rpc_message_note: 'Candidate actual error formatter preserved, including exact generic Arabic error; main control uses it only with successful transport', cases, all_expectations_passed: true, release_acceptance: false }, null, 2));
