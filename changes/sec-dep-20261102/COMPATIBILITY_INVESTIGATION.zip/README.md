# Public compatibility diagnostic capsule

This capsule is evidence/proposal only. It does not alter the application and is not a CI-admitted remediation. See REPORT.md and PROPOSAL.md in the surrounding Git packet.

Environment: Linuxx64, Node24.22.1, official Bun1.4.0 generator/audit and1.2.14 frozen consumer. Official archives and binary SHA512/SHA256 pins are in public-provenance.json and bun/provenance.json. Network access to the public npm registry is required for reproduction; no project/production credentials are used.

To reproduce the public fixture stages in a new directory that does not exist:

```sh
python reproduce.py /absolute/path/to/new-diagnostic-directory
```

The scripts download hash-pinned runtime binaries and public packages without lifecycle scripts, materialize the exact29locked package paths, build isolated dummy-data fixtures, prepare native-patch/vendor alternatives, exercise actual consumer boundaries, and record expected failures/real process exits. Native Bun patch examples use a true existingv1 baseline; do not hand-edit lock headers. Unsupported nested rules produce v3 and fail the1.2.14 consumer by design.

consumer-results.json records five variants ×8boundaries. Three errors in blind-global are expected negative controls; controller exits0 only if other boundaries and exact expected errors match. Actual config-array/eslintrc modules are loaded; TypeScript selected function and Workbox selected function have their explicit harness limits in REPORT.md.

bounded-minimatch.cjs instruments the actual preprocessing methods, with5repetitions max and a small explicit8row cap. The second-phase call uses1001dummy rows and a count-only comparison stub, not adversarial matching work. bounded-glob.cjs seeds15dummy directories/files and observes real readdir calls100ms after an abort. Run each bounded Node probe with --max-old-space-size=128 and a3second controller timeout, as in reproduction steps.

application-audit/ contains only raw audit/receipt evidence; the full private app lock is not duplicated here. Its exact Git blobs are in the receipt and source repository. This audit remains failed. Subset audits cannot establish a clean complete application graph.

Initial errors and corrected receipts are included. The older failed propose-interop output was a hash expectation failure from terminal-LF normalization; the current script permits only that documented normalization on the four expected additions. No other source bytes may change.

No full project install/build/Windows/browser-to-DB/financial acceptance or independent review is implied. Proposed patch/full graph adoption requires the decision in PROPOSAL.md. The unexecuted top-level orchestration is only a reproducibility convenience; actual individual-stage receipts are authoritative.
