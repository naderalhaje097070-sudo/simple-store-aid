const fs=require('fs'),assert=require('assert/strict'),crypto=require('crypto');
const modules='/workspace/scratch/ef360bbe5cf9/simple-store-aid/node_modules/';
const parser=require(modules+'@babel/parser'),ts=require(modules+'typescript'),prettier=require(modules+'prettier');
const dir='/workspace/scratch/5b0bd186aaec/g0-lint-preparation/';
const before=fs.readFileSync(dir+'app.before.tsx','utf8'),after=fs.readFileSync(dir+'app.after.tsx','utf8');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const excluded=new Set(['start','end','loc','extra','leadingComments','trailingComments','innerComments','comments','tokens','errors']);
function clean(x){if(Array.isArray(x))return x.map(clean);if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).filter(([k])=>!excluded.has(k)).map(([k,v])=>[k,clean(v)]));return x;}
const parse=s=>parser.parse(s,{sourceType:'module',plugins:['typescript','jsx']});
const emit=s=>ts.transpileModule(s,{fileName:'app.tsx',compilerOptions:{target:ts.ScriptTarget.ESNext,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.React,removeComments:true}}).outputText;
// Use TypeScript itself to cook each raw JSX text token; no handwritten whitespace algorithm.
function cook(raw){let e=clean(parse(emit('const t = <x>'+raw+'</x>;')));let args=e.program.body[0].declarations[0].init.arguments.slice(2);assert(args.every(x=>x.type==='StringLiteral'));return args.map(x=>x.value).join('');}
function canonical(x){if(Array.isArray(x))return x.map(canonical);if(!x||typeof x!=='object')return x;let y=Object.fromEntries(Object.entries(x).map(([k,v])=>[k,canonical(v)]));
 if(y.type==='JSXElement'||y.type==='JSXFragment'){
  let host=y.type==='JSXElement'&&y.openingElement.name.type==='JSXIdentifier'&&/^[a-z]/.test(y.openingElement.name.name);
  let children=[];
  for(let c of y.children){let value=c.type==='JSXText'?cook(c.value):c.type==='JSXExpressionContainer'&&c.expression.type==='StringLiteral'?c.expression.value:null;
   if(value!==null){if(value==='')continue;if(host&&children.length&&children.at(-1).type==='StringLiteral')children.at(-1).value+=value;else children.push({type:'StringLiteral',value});}else children.push(c);
  }y.children=children;
 }return y;
}
const ast=s=>canonical(clean(parse(s)));
function callCanonical(x){if(Array.isArray(x))return x.map(callCanonical);if(!x||typeof x!=='object')return x;let y=Object.fromEntries(Object.entries(x).map(([k,v])=>[k,callCanonical(v)]));if(y.type==='CallExpression'&&y.callee.type==='MemberExpression'&&y.callee.object.name==='React'&&y.callee.property.name==='createElement'&&y.arguments[0].type==='StringLiteral'){let args=y.arguments.slice(0,2);for(let c of y.arguments.slice(2)){if(c.type==='StringLiteral'&&args.length>2&&args.at(-1).type==='StringLiteral')args.at(-1).value+=c.value;else args.push(c);}y.arguments=args;}return y;}
const comments=s=>parse(s).comments.map(c=>({type:c.type,value:c.value}));
const sourceA=ast(before),sourceB=ast(after);assert.deepEqual(sourceA,sourceB);assert.deepEqual(callCanonical(clean(parse(emit(before)))),callCanonical(clean(parse(emit(after)))));assert.deepEqual(comments(before),comments(after));
const read=n=>JSON.parse(fs.readFileSync(dir+n,'utf8'));
const diag=rs=>rs.flatMap(r=>r.messages.filter(x=>x.ruleId!=='prettier/prettier').map(m=>({path:r.filePath,ruleId:m.ruleId,severity:m.severity,message:m.message,nodeType:m.nodeType,messageId:m.messageId}))).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
assert.deepEqual(diag(read('lint-before.json')),diag(read('lint-after.json')));
let otherCount=0;for(let r of read('lint-before.json')){if(r.filePath.endsWith('/src/routes/_authenticated/app.tsx'))continue;assert.deepEqual(r,read('lint-after.json').find(x=>x.filePath===r.filePath));otherCount++;}
let mutationChecks=[];
for(let [label,a,b] of [['type change','type A = string;','type A = number;'],['custom children segmentation','const x=<Custom>ab</Custom>;','const x=<Custom>a{"b"}</Custom>;'],['host visible whitespace','const x=<span>a b</span>;','const x=<span>ab</span>;'],['callback behavior','const x=()=>fetch("/a");','const x=()=>fetch("/b");']]){assert.notDeepEqual(ast(a),ast(b));mutationChecks.push(label);}
(async()=>{let config=JSON.parse(fs.readFileSync('/workspace/scratch/5b0bd186aaec/lint-work/.prettierrc','utf8'));assert.equal(await prettier.format(before,{...config,filepath:'src/routes/_authenticated/app.tsx'}),after);assert.equal(await prettier.format(after,{...config,filepath:'src/routes/_authenticated/app.tsx'}),after);let result={beforeSha256:hash(before),afterSha256:hash(after),archiveSha256:hash(fs.readFileSync('/workspace/scratch/5b0bd186aaec/g0-lint-preparation.zip')),sourceTypesASTEqual:true,emittedASTEqual:true,commentsEqual:true,nonformatDiagnosticsEqual:true,otherLintFileRecordsByteEqual:otherCount,prettierExactOutput:true,prettierIdempotent:true,negativeControls:mutationChecks,versions:{prettier:prettier.version,typescript:ts.version,babelParser:require(modules+'@babel/parser/package.json').version},limitation:'Local Babel parser is 7.29.2; authoritative CI artifact reports locked 7.29.7. Local proof is corroboration, not a locked-environment run.'};fs.writeFileSync('/workspace/scratch/5b0bd186aaec/lint-independent-proof.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));})().catch(e=>{console.error(e);process.exitCode=1});
