"""Offline B3 evidence replay: stdlib files/JSON/ZIP only; no DB or network."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import zipfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--records', type=Path, required=True)
p.add_argument('--evidence', type=Path, required=True, help='final-native directory')
a = p.parse_args()

def record(name):
    path = a.records / name
    if not path.exists():
        path = a.records / ('review-' + name)
    return json.loads(path.read_text())

expected = record('final-native-expected.json')
assert expected['source'] == '117f59289a01c56aeb764be27acfbb45663ec439'
assert expected['conclusion'] == 'success'
assert all(j['conclusion'] == 'success' for j in expected['jobs'])
fields = ('trial_ends_at', 'subscription_status', 'subscription_plan',
          'paddle_customer_id', 'paddle_subscription_id')
allowed = ('id', 'name', 'owner_user_id', 'created_at', 'updated_at',
           'timezone', 'business_type')
counts = {}
for artifact in expected['artifacts']:
    mode = 'fresh' if 'fresh' in artifact['name'] else 'upgrade'
    path = a.evidence / (artifact['name'] + '.zip')
    directory = a.evidence / artifact['name']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == artifact['digest'].split(':')[1]
    with zipfile.ZipFile(path) as archive:
        for entry in archive.infolist():
            assert not Path(entry.filename).is_absolute()
            assert '..' not in Path(entry.filename).parts
            assert not (directory / entry.filename).is_symlink()
            assert (directory / entry.filename).read_bytes() == archive.read(entry.filename)
    for logged in expected['receipts_from_remote_logs'][mode]:
        report = json.loads((directory / ('entitlement-' + logged['phase'] + '.json')).read_text())
        assert {k:v for k,v in report.items() if k not in ('checks', 'fingerprints')} == logged
        assert report['failed'] == 0 and report['passed'] == len(report['checks'])
        assert all(c['passed'] is True for c in report['checks'])
    cat = json.loads((directory / 'catalog-after.json').read_text())
    report = json.loads((directory / 'entitlement-after.json').read_text())
    controls = {c['name']:c for c in report['checks']}
    assert all(cat['effective']['authenticated'][c][op] is False for c in fields for op in ('insert', 'update'))
    assert all(cat['effective']['authenticated'][c][op] is True for c in allowed for op in ('insert', 'update', 'select'))
    for label in ('banned_old_jwt_minimal_insert', 'closed_old_jwt_minimal_insert',
                  'disabled_employee_old_jwt_minimal_insert', 'disabled_employee_old_jwt_settings'):
        assert controls[label]['status'] == 403 and controls[label]['sqlstate'] == '42501'
        assert controls[label + '_stored_invariance']['passed']
    if mode == 'upgrade':
        old = json.loads((directory / 'catalog-before.json').read_text())
        assert {k for k in old if old[k] != cat[k]} == {'effective', 'column_acl', 'tenant_acl', 'tenant_acl_expanded'}
        assert controls['populated_upgrade_all_data_preserved']['passed']
    raw = (directory / 'advisors.txt').read_text()
    advisories, end = json.JSONDecoder().raw_decode(raw[raw.index('\n[') + 1:])
    assert Counter(c['level'] for c in advisories) == {'WARN':45}
    cleanup = json.loads((directory / 'cleanup.json').read_text())
    assert cleanup == {'source':expected['source'], 'credential_free_canary_rejected':True,
                       'unexpected_ipv4_rejects':0, 'ipv6_rejects':0,
                       'status_removed':True, 'state_removed':True, 'stack_removed':True}
    counts[mode] = report['passed']
audit = record('audit-review.json')
assert audit['exit_code'] == 1 and audit['unique_advisories'] == 8 and len(audit['unique_high']) == 3
print(json.dumps({'source':expected['source'], 'core_evidence_replay':'PASS',
                  'named_native_controls':counts, 'merge_barrier':'DEP-20261021 OPEN',
                  'live_db_or_network_execution':False}))
