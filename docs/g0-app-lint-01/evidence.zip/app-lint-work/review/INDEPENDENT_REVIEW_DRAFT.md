# G0-APP-LINT-01 — Independent focused review (draft)

Outcome: **Blocked pending missing evidence.** No new source defect found in the reviewed candidate. Canonical locked lint/typecheck/Quality evidence on the published candidate is still required. This is not approval of the full PR72, G0 closure, integration acceptance, merge, or deployment.

## Source scope and contracts

Reviewed `src/routes/_authenticated/app.tsx` against the supplied `app.before.tsx`, plus actual `src/lib/db.ts`, shared `AppContext.ts`, and shared `types.ts`. Reviewed candidate SHA-256: `3f466b304aa74c48506d6a8a40068a805c0086eaa8c1c723b25a85a725385665` (Git blob `de992dbc7837877364ff32db0887bec92bc04b2e`). The diagnostic output records the exact baseline and candidate hashes read locally; baseline must be reconciled to the published baseline blob before final approval.

- Screen context reuses the existing AppCtx contract and refines only the three mutation types whose argument/result values are consumed here using the actual hooks' mutateAsync signatures.
- PaymentSheet payload derives from CreateSaleInput; Customer, Courier, Invoice status, totals, state dispatch, and LucideIcon types match existing sources.
- No newly introduced coercive cast, unknown-as assertion, ts-ignore, rule suppression, RPC payload change, financial formula change, selector change, data call change, or Hook dependency change was found.
- Existing product/invoice/payment unknown-as conversions and shared contract looseness remain outside this batch; this cleanup does not claim to remove all application type looseness.
- Settlement membership toggle retains the same condition, selected branch, Set insertion ordering, and returned Set. The old conditional expression's return value was unused.
- The optional error message read now uses a strict nullish check and Reflect.get with the original receiver. This preserves inherited getters and thrown primitive/function semantics. A two-argument Reflect.get version would change strict primitive getter receivers; that intermediate proposal was corrected before acceptance.

## Deferred existing issue

Severity: **Medium (existing; outside behavioral scope)**

File/contract: DebtsScreen customer lookup and click handler.

Evidence: `.find(...)` can yield undefined while a debt row remains visible. Before this batch, clicking that row throws TypeError on `.id` before navigation. Candidate explicitly throws TypeError for undefined before setter/navigation; customer-present behavior is unchanged. Only the diagnostic message is clarified. The missing-data behavior is intentionally preserved, not fixed by filtering debt rows, inventing a customer invariant, asserting non-nullness, or navigating with a fallback identifier.

Risk: An unmatched customer can leave an actionable debt row whose click fails. Resolving that requires a separate behavioral decision with appropriate data/loading/error coverage; totals and financial records must not be silently reduced or hidden.

Required handling: Record as a separate existing issue in the authorized issue handoff. This review does not approve a behavior-changing fix within G0-APP-LINT-01. Release/merge decisions must consider this disclosed existing issue separately.

## Actual independent verification

Ran `node review/independent-replay.mjs` locally under Node v24.19.0: **34/34 passed**, exit 0. Raw output is `review/independent-replay.json`. The script verifies relevant source snippets and source hashes and executes the extracted original/candidate debt click bodies. It compares:

- 18 error values covering nullish, primitive, plain object, Error, function, inherited property, and proxy values.
- Five strict primitive prototype accessors, preserving the original getter receiver.
- Nine settlement toggle cases, including membership and insertion order.
- Two debt callback cases: existing customer and missing customer; setter/navigation effects and error class match. Error text is deliberately not asserted equal.

This is a focused reviewer diagnostic, not a replacement for existing application tests, browser validation, or financial database validation. It does not justify replaying historic security tests or G1.

## Remaining final-review evidence

Inspect actual published candidate diff/scope; lint before/after diagnostics (17 errors/1 warning to 0 errors/1 warning); unchanged useMemo warning; canonical locked typecheck and complete Quality; exact run identity and source SHA/blob; unchanged package/lock/generated sources/lint configuration; and final documented handoff/rollback. Local probe results reported by the implementer are provisional until their canonical evidence is reviewed.
