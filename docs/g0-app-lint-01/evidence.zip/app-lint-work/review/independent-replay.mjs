// Focused reviewer diagnostic only; does not replace the existing application tests.
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const before = fs.readFileSync(path.join(root, "app.before.tsx"), "utf8");
const after = fs.readFileSync(path.join(root, "src/routes/_authenticated/app.tsx"), "utf8");
const sha = (source) => crypto.createHash("sha256").update(source).digest("hex");
const sources = { beforeSha256: sha(before), afterSha256: sha(after) };
const checks = [];

assert(before.includes("console.warn(err?.message);"));
assert(after.includes('Reflect.get(Object(err), "message", err)'));
assert(after.includes("err === null || err === undefined"));
const oldRead = (err) => err?.message;
const newRead = (err) => err === null || err === undefined ? undefined : Reflect.get(Object(err), "message", err);
const samples = [undefined, null, 0, 1, -1, NaN, true, false, "", "text", Symbol("x"), 1n,
  {}, { message: "plain" }, new Error("error"), Object.assign(() => {}, { message: "fn" }),
  Object.create({ message: "inherited" }), new Proxy({ message: "proxy" }, {
    get(target, key, receiver) { return Reflect.get(target, key, receiver); },
  })];
for (const [index, err] of samples.entries()) {
  assert(Object.is(oldRead(err), newRead(err)));
  checks.push(`message sample ${index}`);
}
for (const [proto, input, label] of [
  [String.prototype, "x", "string"], [Number.prototype, 1, "number"],
  [Boolean.prototype, true, "boolean"], [BigInt.prototype, 1n, "bigint"],
  [Symbol.prototype, Symbol("s"), "symbol"],
]) {
  const prior = Object.getOwnPropertyDescriptor(proto, "message");
  Object.defineProperty(proto, "message", {
    configurable: true,
    get: function () { "use strict"; return typeof this; },
  });
  try {
    assert.equal(oldRead(input), label);
    assert.equal(newRead(input), label);
    checks.push(`strict primitive accessor ${label}`);
  } finally {
    if (prior) Object.defineProperty(proto, "message", prior);
    else delete proto.message;
  }
}

assert(before.includes("n.has(id) ? n.delete(id) : n.add(id);"));
assert(after.includes("if (n.has(id)) n.delete(id);\n      else n.add(id);"));
for (const initial of [[], ["a"], ["a", "b"]]) {
  for (const id of ["a", "b", "c"]) {
    const oldSet = new Set(initial);
    const newSet = new Set(initial);
    oldSet.has(id) ? oldSet.delete(id) : oldSet.add(id);
    if (newSet.has(id)) newSet.delete(id); else newSet.add(id);
    assert.deepEqual([...oldSet], [...newSet]);
    checks.push(`settlement toggle ${JSON.stringify(initial)} / ${id}`);
  }
}

function debtClick(source) {
  const member = source.indexOf("p.setOpenCustomerId(r.customer.id);");
  assert(member !== -1);
  const open = source.lastIndexOf("onClick={() => {", member) + "onClick={() => {".length;
  const close = source.indexOf("}}", member);
  return new Function("p", "r", source.slice(open, close));
}
const oldClick = debtClick(before);
const newClick = debtClick(after);
for (const customer of [undefined, { id: "customer-1" }]) {
  function observe(callback) {
    const sideEffects = [];
    const p = {
      setOpenCustomerId(id) { sideEffects.push(["setOpenCustomerId", id]); },
      go(screen) { sideEffects.push(["go", screen]); },
    };
    try { callback(p, { customer }); return { sideEffects, errorClass: null }; }
    catch (error) { return { sideEffects, errorClass: error.constructor.name }; }
  }
  const oldOutcome = observe(oldClick);
  const newOutcome = observe(newClick);
  assert.deepEqual(oldOutcome, newOutcome);
  if (customer === undefined) assert.deepEqual(newOutcome, { sideEffects: [], errorClass: "TypeError" });
  checks.push(`debt click ${customer === undefined ? "missing" : "present"}`);
}

const result = {
  generatedAt: new Date().toISOString(),
  runtime: process.version,
  sources,
  passed: checks.length,
  checks,
  limits: [
    "Focused runtime expressions and extracted debt click only; not a browser or financial end-to-end test.",
    "Missing-customer failure remains intentionally unfixed; TypeError message changes to a stable explicit message.",
    "Canonical locked CI is separately required; no Quality result is inferred from this diagnostic.",
  ],
};
fs.writeFileSync(path.join(root, "review/independent-replay.json"), JSON.stringify(result, null, 2) + "\n");
console.log(JSON.stringify(result, null, 2));
