const fs=require('node:fs'),path=require('node:path');
const root=__dirname,rows=[];
for(const [label,entry] of [['locked10','fixtures/baseline/node_modules/glob/node_modules/minimatch'],['patched11','fixtures/patched-engine/node_modules/glob/node_modules/minimatch']]){
 const {Minimatch}=require(path.join(root,entry));
 const original=Minimatch.prototype.firstPhasePreProcess;
 let observed;
 Minimatch.prototype.firstPhasePreProcess=function(parts){const initial=parts.length;const result=original.call(this,parts);observed={input_rows:initial,output_rows:result.length};return result;};
 for(const budget of [undefined,8])for(const n of [1,2,3,4,5]){
  observed=null;const pattern=Array.from({length:n},(_,i)=>`**/../x${i}/y${i}/`).join('')+'file.js';
  const m=new Minimatch(pattern,{optimizationLevel:2,...(budget===undefined?{}:{braceExpandMax:budget})});rows.push({engine:label,repetitions:n,braceExpandMax:budget??'default',pattern_length:pattern.length,first_phase:observed,final_rows:m.globParts.length});
 }
 Minimatch.prototype.firstPhasePreProcess=original;
 const m=new Minimatch('literal');let comparisons=0;
 m.partsMatch=()=>{comparisons++;return false;};
 m.secondPhasePreProcess(Array.from({length:1001},(_,i)=>['literal'+i]));
 rows.push({engine:label,actual_second_phase_entry:true,rows:1001,partsMatch_comparisons:comparisons,comparison_body:'count only; false; no pattern engine work'});
}
fs.writeFileSync(path.join(root,'bounded-minimatch-results.json'),JSON.stringify({bounds:{max_repetitions:5,max_old_space_mb:128,timeout_seconds:3},runtime:process.version,observations:rows,production_calls:0},null,2)+'\n');
console.log(JSON.stringify(rows));
