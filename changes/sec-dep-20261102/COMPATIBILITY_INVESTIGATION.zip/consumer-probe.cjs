const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const {pathToFileURL}=require('node:url');
const {createRequire}=require('node:module');
const assert=require('node:assert/strict');
const ROOT=__dirname, files=path.join(ROOT,'dummy-files'), results=[];
async function probe(variant,name,fn){
  try{const observed=await fn();results.push({variant,name,status:'pass',observed});}
  catch(e){results.push({variant,name,status:'error',error:e.name,message:e.message});}
}
function workboxFunction(glob){
  const file=path.join(ROOT,'packages/inspect/workbox-build/build/lib/get-file-details.js');
  const source=fs.readFileSync(file,'utf8'),exports={};
  // Actual Workbox getFileDetails body, with explicit Node filesystem/path
  // adapters for unrelated imports. This is not a complete Workbox build.
  const require=(name)=>{
    if(name==='glob')return glob;
    if(name==='upath')return path.posix;
    if(name==='./errors')return {errors:{'unable-to-glob-files':'fixture glob error','useless-glob-pattern':'fixture empty'}};
    if(name==='./get-file-size')return {getFileSize:p=>fs.statSync(p).isFile()?fs.statSync(p).size:null};
    if(name==='./get-file-hash')return {getFileHash:p=>crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex')};
    throw Error('unexpected fixture import '+name);
  };
  vm.runInNewContext(source,{exports,require},{filename:file,timeout:1000});
  return exports.getFileDetails;
}
(async()=>{
for(const variant of ['baseline','patched-engine','blind-global','compatibility-proposal','vendor-interop-proposal']){
  const dir=path.join(ROOT,'fixtures',variant),node=path.join(dir,'node_modules');
  await probe(variant,'legacy_callable_export',()=>{
    const mm=require(path.join(node,'minimatch'));
    assert.equal(mm('x.js','*.js'),true);assert.equal(mm('x.css','*.js'),false);return {callable:typeof mm};
  });
  await probe(variant,'actual_config_array_CJS',()=>{
    const {ConfigArray}=require(path.join(node,'@eslint/config-array/dist/cjs/index.cjs'));
    const configs=new ConfigArray([{files:['**/*.js'],ignores:['**/skip.js'],tag:'js'}],{basePath:files,schema:{tag:{merge:'replace',validate:'string'}}});
    configs.normalizeSync();assert.equal(configs.getConfig(path.join(files,'a.js')).tag,'js');
    assert.equal(configs.getConfig(path.join(files,'b.css')),undefined);
    assert.equal(configs.getConfig(path.join(files,'skip.js')),undefined);return {positive_and_2_negatives:true};
  });
  await probe(variant,'actual_config_array_ESM_entry',async()=>{
    const mod=await import(pathToFileURL(path.join(dir,'esm-entry.mjs')).href);
    assert.equal(typeof mod.ConfigArray,'function');return {imported:true};
  });
  await probe(variant,'actual_filelist_glob',()=>{
    const {FileList}=require(path.join(node,'filelist'));
    const actual=new FileList(path.join(files,'**/*.js')).toArray().map(f=>path.relative(files,f)).sort();
    assert.deepEqual(actual,['a.js','skip.js','sub/c.js']);return {files:actual};
  });
  await probe(variant,'actual_eslintrc_ESM_override_tester',async()=>{
    const file=path.join(node,'@eslint/eslintrc/lib/config-array/override-tester.js');
    const {OverrideTester}=await import(pathToFileURL(file).href);
    const test=OverrideTester.create(['**/*.js'],['**/skip.js'],files);
    assert.equal(test.test(path.join(files,'a.js')),true);
    assert.equal(test.test(path.join(files,'skip.js')),false);
    assert.equal(test.test(path.join(files,'b.css')),false);
    assert.throws(()=>OverrideTester.create(['../*.js'],[],files),/Invalid override pattern/);
    return {positive_and_3_negatives:true};
  });
  await probe(variant,'actual_typescript_estree_match_function',()=>{
    const source=fs.readFileSync(path.join(ROOT,'packages/inspect/@typescript-eslint/typescript-estree/dist/useProgramFromProjectService.js'),'utf8');
    const matches=source.match(/function filePathMatchedBy\(filePath, allowDefaultProject\) \{\n[^\n]+\n\}/g);
    assert.equal(matches.length,1);
    const engine=createRequire(path.join(node,'glob/package.json'))('minimatch');
    const ctx={minimatch_1:engine};vm.runInNewContext(matches[0]+'\nthis.test=filePathMatchedBy;',ctx,{timeout:1000});
    assert.equal(ctx.test('.config.ts',['*.ts']),true);
    assert.equal(ctx.test('x.css',['*.ts']),false);assert.equal(ctx.test('x.ts',undefined),false);
    return {actual_function:true,positive_and_2_negatives:true,full_typescript_lint:false};
  });
  await probe(variant,'actual_glob_sync_and_async',async()=>{
    const glob=require(path.join(node,'glob'));
    const expected=['a.js','sub/c.js'];const opts={cwd:files,ignore:['**/skip.js']};
    assert.deepEqual(glob.globSync('**/*.js',opts).sort(),expected);
    assert.deepEqual((await glob.glob('**/*.js',opts)).sort(),expected);return {files:expected};
  });
  await probe(variant,'actual_workbox_function_glob_boundary',()=>{
    const get=workboxFunction(require(path.join(node,'glob')));
    const result=get({globDirectory:files,globPattern:'**/*.js',globFollow:false,globIgnores:['**/skip.js']});
    assert.deepEqual(Array.from(result.globbedFileDetails,d=>({file:d.file,size:d.size,hash:d.hash})).sort((a,b)=>a.file.localeCompare(b.file)),[
      {file:'a.js',size:5,hash:crypto.createHash('md5').update('alpha').digest('hex')},
      {file:'sub/c.js',size:5,hash:crypto.createHash('md5').update('child').digest('hex')}
    ]);assert.equal(result.warning,'');return {files:2,actual_function:true,explicit_filesystem_adapters:true};
  });
}
const baseline=results.filter(x=>x.variant==='baseline');
assert.equal(baseline.length,8);assert.ok(baseline.every(x=>x.status==='pass'),JSON.stringify(baseline));
const scoped=results.filter(x=>x.variant==='patched-engine');assert.ok(scoped.every(x=>x.status==='pass'),JSON.stringify(scoped));
const proposal=results.filter(x=>x.variant==='vendor-interop-proposal');assert.equal(proposal.length,8);assert.ok(proposal.every(x=>x.status==='pass'),JSON.stringify(proposal));
const nativePatch=results.filter(x=>x.variant==='compatibility-proposal');assert.equal(nativePatch.length,8);assert.ok(nativePatch.every(x=>x.status==='pass'),JSON.stringify(nativePatch));
const blind=results.filter(x=>x.variant==='blind-global');
assert.deepEqual(blind.filter(x=>x.status==='error').map(x=>x.name),['legacy_callable_export','actual_config_array_ESM_entry','actual_eslintrc_ESM_override_tester']);
fs.writeFileSync(path.join(ROOT,'consumer-results.json'),JSON.stringify({runtime:process.version,controller:'bounded baseline/scoped controls; expected blind-override rejections',controls:results,application_changes:0,full_install_or_PWA_build:false},null,2)+'\n');
console.log(JSON.stringify(results,null,2));
})().catch(e=>{fs.writeFileSync(path.join(ROOT,'consumer-failed.json'),JSON.stringify({results,error:e.stack},null,2)+'\n');console.error(e);process.exitCode=1;});
